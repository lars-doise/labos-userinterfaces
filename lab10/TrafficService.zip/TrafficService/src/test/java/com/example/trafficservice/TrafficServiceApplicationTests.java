package com.example.trafficservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrafficServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
