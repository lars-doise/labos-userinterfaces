package com.example.trafficservice.notification;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@RestController
public class NotificationController {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private final NotificationDAO notificationDAO;

    public NotificationController(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
    }

    @GetMapping("/notifications")
    public List<Notification> getNotification(){
        return notificationDAO.getAllNotifications();
    }

    @GetMapping("/notifications/{id}")
    public Notification getNotification(@PathVariable("id") UUID uuid){
        return notificationDAO.getNotification(uuid).orElseThrow(IllegalArgumentException::new);
    }

    @PostMapping("/notifications")
    public ResponseEntity<Void> addNotification(@RequestBody Notification notification) {
        notificationDAO.addNotification(notification);
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(notification.getUuid())
                .toUri();
        return ResponseEntity.created(location).build();
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(IllegalArgumentException.class)
    public void handleNotFound(Exception ex) {
        logger.error("Exception is: ", ex);
        // return empty 404
    }
}

