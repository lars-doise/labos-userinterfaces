package com.example.trafficservice.notification;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface NotificationDAO {
    void addNotification(Notification notification);
    List<Notification> getAllNotifications();
    Optional<Notification> getNotification(UUID uuid);
}
