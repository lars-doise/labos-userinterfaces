package com.example.trafficservice.notification;

import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.aspectj.weaver.ast.Not;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class NotificationDAOImpl implements NotificationDAO{
    private final NotificationRepository repository;

    public NotificationDAOImpl(NotificationRepository repository) {
        this.repository = repository;
        initDAO();
    }

    @Override
    public void addNotification(Notification notification) {
        repository.save(notification);
    }

    @Override
    public List<Notification> getAllNotifications() {
        return repository.findAll();
    }

    @Override
    public Optional<Notification> getNotification(UUID uuid) {
        return repository.findById(uuid);
    }

    private void initDAO(){
        JSONParser parser = null;
        try {
            Path path = Paths.get("src/main/resources/static/verkeersmeldingen.json");
            parser = new JSONParser(new FileReader(path.toAbsolutePath().toString()));
            LinkedHashMap<String, Object> json = parser.object();
            List<Object> notifications = (List<Object>)json.get("result");

            for (Object notificationObject : notifications){
                LinkedHashMap<String, Object> notification = (LinkedHashMap<String, Object>) notificationObject;
                LinkedHashMap<String, Object> notificationPayload = (LinkedHashMap<String, Object>)notification.get("payload");

                Notification not = new Notification();
                not.setName(notification.get("alarmName").toString());
                not.setSource(notification.get("source").toString());
                not.setType(notification.get("type").toString());
                not.setTransport(notification.get("transport").toString());
                if(notificationPayload.containsKey("message")){
                    not.setMessage(notificationPayload.get("message").toString());
                }
                if(notificationPayload.containsKey("longitude")){
                    not.setLongitude(((BigDecimal)notificationPayload.get("longitude")).doubleValue());
                }
                if(notificationPayload.containsKey("latitude")){
                    not.setLatitude(((BigDecimal)notificationPayload.get("latitude")).doubleValue());
                }
                not.setDate(notification.get("timestamp").toString());

                addNotification(not);
            }
        } catch (FileNotFoundException | ParseException e) {
            e.printStackTrace();
        }
    }
}
