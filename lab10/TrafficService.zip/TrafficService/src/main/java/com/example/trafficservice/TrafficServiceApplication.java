package com.example.trafficservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrafficServiceApplication {

    public static void main(String[] args) {

        SpringApplication.run(TrafficServiceApplication.class, args);
    }

}
