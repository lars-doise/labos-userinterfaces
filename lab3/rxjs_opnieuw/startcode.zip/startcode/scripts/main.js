let numOfCards = 0;
let numOfRows = 0;

function addCard(title, value) {
    let main = document.getElementsByTagName("main")[0];

    let col = document.createElement("div");
    col.setAttribute("class", "col-md-4");

    let card = document.createElement("div");
    card.setAttribute("class", "card mb-4");
    card.setAttribute("id", "card_" + numOfCards);

    let card_header = document.createElement("div");
    card_header.setAttribute("class", "card-header");
    card_header.innerText = title;
    let card_body = document.createElement("div");
    card_body.setAttribute("class", "card-body");

    let card_body_text = document.createElement("p");
    card_body_text.setAttribute("class", "card-text");
    card_body_text.innerText = value;

    card_body.appendChild(card_body_text);
    card.appendChild(card_header);
    card.appendChild(card_body);
    col.appendChild(card);

    if (numOfCards % 3 === 0) {
        numOfRows++;

        let row = document.createElement("div")
        row.setAttribute("class", "row");
        row.setAttribute("id", "row_" + numOfRows);

        row.appendChild(col);
        main.appendChild(row);
    } else {
        let row = document.getElementById("row_" + numOfRows);
        row.appendChild(col);
    }

    numOfCards++;
}