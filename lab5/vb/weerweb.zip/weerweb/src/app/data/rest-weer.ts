export interface RestWeer {
  list: any;
}
