import { Land } from './land';

describe('Land', () => {
  it('should create an instance', () => {
    expect(new Land()).toBeTruthy();
  });
});
