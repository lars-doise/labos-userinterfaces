import { Weer } from './weer';

describe('Weer', () => {
  it('should create an instance', () => {
    expect(new Weer()).toBeTruthy();
  });
});
