export interface RestCountry {
  cca2: string;
  name: any;
  capital: string[];
}

