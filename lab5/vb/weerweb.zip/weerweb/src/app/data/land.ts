export class Land {
  constructor(public code: string, public naam: string, public hoofdstad: string) {
    this.code = code;
    this.naam = naam;
    this.hoofdstad = hoofdstad;
  }
}
