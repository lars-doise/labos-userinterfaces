import { Component } from '@angular/core';
import {Newsitem} from "./data/newsitem";

//import {Observable} from "rxjs/dist/types";
import {Observable} from "rxjs";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(){}
  ngOnInit(){
  }
}
