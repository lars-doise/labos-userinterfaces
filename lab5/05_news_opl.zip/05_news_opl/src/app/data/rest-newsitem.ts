export interface RestNewsitem{
  id:number;
  category:string;
  subcategory:string;
  title:string;
  content:string;
}
