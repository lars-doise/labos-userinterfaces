export class Notif{
  constructor(public id:number, public message: string, public icon: string){
    //-/ console.log(`notification gevonden met info ${this.id} ${this.message} ${this.icon}`);
  }
}
