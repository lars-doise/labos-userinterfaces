export interface RestNotif{
  id:number;
  message:string;
  icon:string;
}
